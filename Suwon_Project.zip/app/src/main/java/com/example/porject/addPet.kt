package com.example.porject

import android.content.Intent
import android.os.Bundle
import android.os.PersistableBundle
import androidx.appcompat.app.AppCompatActivity
import com.example.porject.databinding.ActivityMainBinding
import com.example.porject.databinding.FragmentMyPetBinding
import com.example.porject.databinding.LayoutAddPetBinding

class addPet : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?) {
        super.onCreate(savedInstanceState)
        val binding = LayoutAddPetBinding.inflate(layoutInflater)
        setContentView(binding.root)
        /*'
        binding.addPetImagebutton.setOnClickListener(){

        }
         */
        binding.addInputPetDataButton.setOnClickListener(){
            var fragment2 = myPet()
            var bundle = Bundle()
            val intent = Intent(this, myPet::class.java)
            val pettext = binding.addPetNameEdittext.text.toString()
            val pettypetext = binding.addPetTypeEdittext.text.toString()
            val lastwalkdaytext = binding.addPetLastwalkdayEdittext.text.toString()
            val eattypetext = binding.addPetEattypeEdittext.text.toString()
            bundle.putString("PetNameData", pettext)
            bundle.putString("PetTypeText", pettypetext)
            bundle.putString("LastWalkDayText", lastwalkdaytext)
            bundle.putString("EatTypeText", eattypetext)
            fragment2.arguments = bundle
            startActivity(intent)
        }
    }
}