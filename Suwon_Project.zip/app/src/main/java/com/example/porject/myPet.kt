package com.example.porject

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.porject.databinding.ActivityMainBinding
import com.example.porject.databinding.FragmentMyPetBinding

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [myPet.newInstance] factory method to
 * create an instance of this fragment.
 */
class myPet : Fragment(), View.OnClickListener {
    // TODO: Rename and change types of parameters
    lateinit var binding: FragmentMyPetBinding
    private var param1: String? = null
    private var param2: String? = null
    /*
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val items = mutableListOf<ListViewItem>()
        val binding = FragmentMyPetBinding.inflate(layoutInflater)
        setContentView(binding.root)

        items.add(ListViewItem(ContextCompat.getDrawable(this, androidx.appcompat.R.drawable.abc_btn_radio_material)!!, "aa", "Dd"))
        items.add(ListViewItem(ContextCompat.getDrawable(this, androidx.appcompat.R.drawable.abc_btn_radio_material)!!, "bb", "Dd"))
        items.add(ListViewItem(ContextCompat.getDrawable(this, androidx.appcompat.R.drawable.abc_btn_radio_material)!!, "cc", "Dd"))

        val adapter = ListViewAdapter(items)
        binding.petListView.adapter = adapter

        binding.petListView.setOnItemClickListener{ parent: AdapterView<*>, view: View, position: Int, id: Long ->
            val item = parent.getItemAtPosition(position) as ListViewItem
            Toast.makeText(this, item.title, Toast.LENGTH_SHORT).show()
        }
    }
     */

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
        binding.petNameTextview.text = arguments?.getString("PetNameData")
        binding.petTypeTextview.text = arguments?.getString("PetTypeData")
        binding.petLastwalkdayTextview.text = arguments?.getString("LastWalkDayData")
        binding.petEattypeTextview.text = arguments?.getString("EatTypeData")
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_my_pet, container, false)
    }
    //binding .. set
    override fun onClick(p0: View?) {
        if (p0 != null) {
            when (p0.id){
                R.id.add_pet_button -> {
                    val intent = Intent(activity, addPet::class.java)
                    startActivity(intent)
                }
            }
        }
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment myPet.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            myPet().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}